/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class RandomWalkers {
    public static void main(String[] args) {
        int r = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);

        long totalSteps = 0;
        for (int i = 0; i < trials; i++) {

            int x = 0, y = 0;
            int steps = 0;
            while (Math.abs(x) + Math.abs(y) < r) {
                steps++;
                double dice = Math.random() * 4;

                if (dice < 1) y++;
                else if (dice < 2) x++;
                else if (dice < 3) y--;
                else x--;
            }

            totalSteps += steps;
        }
        double avgSteps = (double) totalSteps / trials;

        System.out.println("average number of steps = " + avgSteps);
    }
}
