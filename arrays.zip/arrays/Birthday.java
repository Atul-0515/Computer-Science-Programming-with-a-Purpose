/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class Birthday {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);


        int[] arr = new int[n + 10];

        for (int i = 0; i < trials; i++) {
            int count = 0;
            boolean[] found = new boolean[n];

            while (true) {
                count++;
                int r = (int) (Math.random() * n);
                if (found[r]) break;
                found[r] = true;
            }
            if (count < arr.length) arr[count]++;
        }

        double fraction = 0.0;
        int cummulutiveCount = 0;
        for (int i = 1; i < arr.length; i++) {
            cummulutiveCount += arr[i];
            fraction = (double) cummulutiveCount / trials;

            System.out.printf("%d %d %.5f%n", i, arr[i], fraction);

            if (fraction >= 0.50) break;
        }
    }
}
