/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class Minesweeper {
    public static void main(String[] args) {
        int m = Integer.parseInt(args[0]);
        int n = Integer.parseInt(args[1]);
        int k = Integer.parseInt(args[2]);

        int[][] minePath = new int[m + 2][n + 2];
        {
            int i = 0;
            while (i < k) {
                int rm = 1 + (int) (Math.random() * m);
                int rn = 1 + (int) (Math.random() * n);

                if (minePath[rm][rn] != -1) {
                    minePath[rm][rn] = -1;
                    i++;
                }
            }
        }

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (minePath[i][j] == -1) continue;
                int mines = 0;
                if (minePath[i - 1][j] == -1) mines++;
                if (minePath[i + 1][j] == -1) mines++;
                if (minePath[i][j - 1] == -1) mines++;
                if (minePath[i][j + 1] == -1) mines++;
                if (minePath[i - 1][j - 1] == -1) mines++;
                if (minePath[i - 1][j + 1] == -1) mines++;
                if (minePath[i + 1][j - 1] == -1) mines++;
                if (minePath[i + 1][j + 1] == -1) mines++;

                minePath[i][j] = mines;
            }
        }

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++)
                if (minePath[i][j] == -1)
                    System.out.print("*  ");
                else
                    System.out.print(minePath[i][j] + "  ");
            System.out.println();
        }
    }

}
