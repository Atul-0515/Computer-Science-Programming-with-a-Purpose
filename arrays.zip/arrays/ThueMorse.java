/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class ThueMorse {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        boolean[] arr = new boolean[n];

        {
            int i = 1;
            while (i <= n) {
                int k = 0;
                int end = Math.min(2 * i, n);
                for (int j = i; j < end; j++) {
                    arr[j] = !arr[k];
                    k++;
                }
                i *= 2;
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i] == arr[j])
                    System.out.print("+  ");
                else System.out.print("-  ");
            }
            System.out.println();
        }

    }
}
