/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class DiscreteDistribution {
    public static void main(String[] args) {
        int m = Integer.parseInt(args[0]);
        int N = args.length;

        int[] arr = new int[N];
        for (int i = 1; i < N; i++)
            arr[i] = arr[i - 1] + Integer.parseInt(args[i]);


        for (int i = 0; i < m; i++) {
            double r = Math.random() * arr[N - 1];

            for (int j = 1; j < N; j++) {
                if (r < arr[j]) {
                    System.out.print(j + " ");
                    break;
                }
            }
        }
        System.out.println();
    }
}
