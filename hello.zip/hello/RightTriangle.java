/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class RightTriangle {
    public static void main(String[] args) {
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        int min = Math.min(a, b);
        int max = Math.max(a, b);

        int c = Integer.parseInt(args[2]);
        min = Math.min(min, c);
        max = Math.max(max, c);

        int mid = (a + b + c) - (min + max);


        boolean isRightTriangle = min > 0;
        isRightTriangle = isRightTriangle && (min * min + mid * mid == max * max);

        System.out.println(isRightTriangle);
    }
}
