/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class RevesPuzzle {
    private static void hanoi(int n0, int n, char s, char d, char t) {
        if (n <= 0) return;
        hanoi(n0, n - 1, s, t, d);
        StdOut.printf("Move disc %d from %c to %c%n", n + n0, s, d);
        hanoi(n0, n - 1, t, d, s);
    }

    private static void reves(int n, char s, char d, char h1, char h2) {
        if (n <= 0) return;
        int k = (int) (Math.round(n + 1 - Math.sqrt(2 * n + 1)));
        reves(k, s, h1, d, h2);
        hanoi(k, n - k, s, d, h2);
        reves(k, h1, d, s, h2);
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        char a = 'A', b = 'B', c = 'C', d = 'D';
        reves(n, a, d, b, c);
    }
}
