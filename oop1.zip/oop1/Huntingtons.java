/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class Huntingtons {
    public static int maxRepeats(String dna) {
        int maxCnt = 0;
        int cnt = 0;

        int i = 0;
        while (i < dna.length()) {
            if (dna.startsWith("CAG", i)) {
                cnt++;
                maxCnt = Math.max(maxCnt, cnt);
                i += 3;
            }
            else {
                cnt = 0;
                i++;
            }
        }
        return maxCnt;

    }


    public static String removeWhitespace(String s) {
        s = s.replace('\n', ' ');
        s = s.replace('\t', ' ');
        s = s.replace(" ", "");
        return s;
    }

    public static String diagnose(int maxRepeats) {
        if (maxRepeats < 10) return "not human";
        if (maxRepeats <= 35) return "normal";
        if (maxRepeats <= 39) return "high risk";
        if (maxRepeats <= 180) return "Huntington's";
        return "not human";
    }

    public static void main(String[] args) {
        String filename = args[0];
        String data = new In(filename).readAll();
        String cleaneddata = removeWhitespace(data);

        int maxRepeats = maxRepeats(cleaneddata);
        StdOut.printf("max repeats = %d%n", maxRepeats);
        StdOut.println(diagnose(maxRepeats));
    }
}
