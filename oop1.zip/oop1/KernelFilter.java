/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import java.awt.Color;

public class KernelFilter {

    private static Color mulMatrix(double[][] filter, double[][][] subPic) {
        double r = 0.0, g = 0.0, b = 0.0;
        for (int i = 0; i < filter.length; i++) {
            for (int j = 0; j < filter.length; j++) {
                r += filter[i][j] * subPic[i][j][0];
                g += filter[i][j] * subPic[i][j][1];
                b += filter[i][j] * subPic[i][j][2];
            }
        }
        int r1 = (int) Math.max(0, Math.min(255, Math.round(r)));
        int g1 = (int) Math.max(0, Math.min(255, Math.round(g)));
        int b1 = (int) Math.max(0, Math.min(255, Math.round(b)));

        return new Color(r1, g1, b1);
    }

    private static Picture applyFilter(double[][] filter, Picture source) {
        int w = source.width();
        int h = source.height();
        Picture target = new Picture(w, h);

        int filterLen = filter.length;
        int halfFilterLen = filter.length / 2;
        double[][][] temp = new double[filterLen][filterLen][3];

        /**
         * code to apply the given filter */
        for (int col = 0; col < w; col++) {
            for (int row = 0; row < h; row++) {

                for (int ti = 0, i = col - halfFilterLen; i <= col + halfFilterLen; i++, ti++) {
                    for (int tj = 0, j = row - halfFilterLen; j <= row + halfFilterLen; j++, tj++) {
                        int idxI = (i + w) % w;
                        int idxJ = (j + h) % h;
                        Color c = source.get(idxI, idxJ);

                        temp[ti][tj][0] = c.getRed();
                        temp[ti][tj][1] = c.getGreen();
                        temp[ti][tj][2] = c.getBlue();

                    }
                }

                target.set(col, row, mulMatrix(filter, temp));
            }
        }

        return target;
    }

    public static Picture identity(Picture picture) {
        double[][] kernel = {
                { 0, 0, 0 },
                { 0, 1, 0 },
                { 0, 0, 0 }
        };
        return applyFilter(kernel, picture);
    }

    public static Picture gaussian(Picture picture) {
        double[][] kernel = {
                { 1, 2, 1 },
                { 2, 4, 2 },
                { 1, 2, 1 }
        };
        for (int i = 0; i < kernel.length; i++)
            for (int j = 0; j < kernel[i].length; j++)
                kernel[i][j] *= 1.0 / 16;
        return applyFilter(kernel, picture);

    }

    public static Picture sharpen(Picture picture) {
        double[][] kernel = {
                { 0, -1, 0 },
                { -1, 5, -1 },
                { 0, -1, 0 }
        };
        return applyFilter(kernel, picture);
    }

    public static Picture laplacian(Picture picture) {
        double[][] kernel = {
                { -1, -1, -1 },
                { -1, 8, -1 },
                { -1, -1, -1 }
        };
        return applyFilter(kernel, picture);
    }

    public static Picture emboss(Picture picture) {
        double[][] kernel = {
                { -2, -1, 0 },
                { -1, 1, 1 },
                { 0, 1, 2 }
        };
        return applyFilter(kernel, picture);
    }

    public static Picture motionBlur(Picture picture) {
        double[][] kernel = new double[9][9];
        for (int i = 0; i < kernel.length; i++)
            kernel[i][i] = 1.0 / 9;
        return applyFilter(kernel, picture);
    }

    public static void main(String[] args) {
        Picture input = new Picture("baboon.png");

        Picture identity = identity(input);
        Picture gaussian = gaussian(input);
        Picture sharpen = sharpen(input);
        Picture laplacian = laplacian(input);
        Picture emboss = emboss(input);
        Picture motionBlur = motionBlur(input);

        identity.show();
        gaussian.show();
        sharpen.show();
        laplacian.show();
        emboss.show();
        motionBlur.show();


    }
}
