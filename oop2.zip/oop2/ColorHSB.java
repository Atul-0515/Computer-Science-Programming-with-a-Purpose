/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class ColorHSB {
    private final int hue;
    private final int saturation;
    private final int brightness;

    public ColorHSB(int h, int s, int b) {
        if (h < 0 || h > 359 || s < 0 || s > 100 || b < 0 || b > 100)
            throw new IllegalArgumentException();
        hue = h;
        saturation = s;
        brightness = b;
    }

    public String toString() {
        return "(" + hue + "," + saturation + "," + brightness + ")";
    }

    public boolean isGrayscale() {
        return saturation == 0 || brightness == 0;
    }

    public int distanceSquaredTo(ColorHSB that) {
        if (that == null)
            throw new IllegalArgumentException();

        int disH1 = (int) (Math.pow(hue - that.hue, 2));
        int disH2 = (int) (Math.pow(360 - Math.abs(hue - that.hue), 2));

        int disS = (int) (Math.pow(saturation - that.saturation, 2));
        int disB = (int) (Math.pow(brightness - that.brightness, 2));

        return Math.min(disH1, disH2) + disS + disB;
    }


    public static void main(String[] args) {
        int h = Integer.parseInt(args[0]);
        int s = Integer.parseInt(args[1]);
        int b = Integer.parseInt(args[2]);

        ColorHSB color1 = new ColorHSB(h, s, b);

        int minDis = Integer.MAX_VALUE;
        String color = "";
        ColorHSB colorReq = new ColorHSB(h, s, b);

        while (!StdIn.isEmpty()) {
            String colorName = StdIn.readString();

            h = StdIn.readInt();
            s = StdIn.readInt();
            b = StdIn.readInt();
            ColorHSB color2 = new ColorHSB(h, s, b);

            int dis = color1.distanceSquaredTo(color2);
            if (dis < minDis) {
                minDis = dis;
                color = colorName;
                colorReq = new ColorHSB(h, s, b);
            }
        }

        StdOut.println(color + " " + colorReq);
    }
}
