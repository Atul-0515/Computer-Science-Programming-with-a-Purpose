/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class Clock {
    private int hr;
    private int min;

    public Clock(int h, int m) {
        if (h < 0 || h > 23 || m < 0 || m > 59)
            throw new IllegalArgumentException();
        hr = h;
        min = m;
    }

    public Clock(String s) {
        if (s.length() != 5 || s.charAt(2) != ':')
            throw new IllegalArgumentException();

        if (!Character.isDigit(s.charAt(0)) ||
                !Character.isDigit(s.charAt(1)) ||
                !Character.isDigit(s.charAt(3)) ||
                !Character.isDigit(s.charAt(4))) {
            throw new IllegalArgumentException();
        }

        int h, m;
        h = 10 * (s.charAt(0) - '0') + (s.charAt(1) - '0');
        m = 10 * (s.charAt(3) - '0') + (s.charAt(4) - '0');

        if (h < 0 || h > 23 || m < 0 || m > 59)
            throw new IllegalArgumentException();

        hr = h;
        min = m;
    }

    public String toString() {
        String hour, minute;
        if (hr < 10) hour = "0" + hr;
        else hour = "" + hr;
        if (min < 10) minute = "0" + min;
        else minute = "" + min;
        return hour + ":" + minute;
    }

    public boolean isEarlierThan(Clock that) {
        return hr * 100 + min < that.hr * 100 + that.min;
    }

    public void tic() {
        if (min != 59)
            min++;
        else {
            if (hr == 23) {
                hr = 0;
                min = 0;
            }
            else {
                hr++;
                min = 0;
            }
        }
    }

    public void toc(int delta) {
        if (delta < 0)
            throw new IllegalArgumentException();
        int hrToInc = delta / 60;
        delta = delta - 60 * hrToInc;

        int newMin = min + delta;
        hrToInc += newMin / 60;

        hr = (hr + hrToInc) % 24;
        min = newMin % 60;

    }

    public static void main(String[] args) {

        Clock clock1 = new Clock(12, 30);
        Clock clock2 = new Clock("14:45");

        StdOut.println(clock1);
        StdOut.println(clock2);

        StdOut.println(clock1.isEarlierThan(clock2));

        clock1.tic();
        StdOut.println(clock1);

        clock2.toc(90);
        StdOut.println(clock2);

    }
}
