/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class Ramanujan {
    public static boolean isRamanujan(long n) {
        double eps = 1.0e-15;
        long a = 0, b = 0;
        for (long i = 1; i < Math.cbrt(n); i++) {
            double t = Math.cbrt(n - i * i * i);
            if ((t - Math.floor(t)) < eps) {
                a = i;
                b = (long) t;
                break;
            }
        }
        long c = 0, d = 0;
        for (long i = a + 1; i < Math.cbrt(n - a * a * a); i++) {
            double t = Math.cbrt(n - i * i * i);
            if ((t - Math.floor(t) < eps)) {
                c = i;
                d = (long) t;
                return true;
            }
        }
        return false;

    }

    public static void main(String[] args) {
        long n = Long.parseLong(args[0]);
        StdOut.println(isRamanujan(n));
    }
}
