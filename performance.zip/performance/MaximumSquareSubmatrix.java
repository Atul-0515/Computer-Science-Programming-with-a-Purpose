/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class MaximumSquareSubmatrix {

    /* O(N^4)
    private static boolean isContig(int[][] a, int n) {
        for (int i = 0; i <= a.length - n; i++) {
            for (int j = 0; j <= a[0].length - n; j++) {

                boolean hasZeros = false;
                for (int k = i; (k < i + n) && !hasZeros; k++)
                    for (int l = j; l < j + n; l++)
                        if (a[k][l] == 0) {
                            hasZeros = true;
                            break;
                        }
                if (!hasZeros) return true;

            }
        }
        return false;
    }
     */


    public static int size(int[][] a) {
        /* calling to O(N^4) function
        if (a.length == 0) return 0;
        for (int i = a.length; i > 1; i--)
            if (isContig(a, i)) return i;
        return 1;
         */

        if (a.length == 0 || a[0].length == 0) return 0;
        int n = a.length, m = a[0].length;

        int[][] s = new int[n][m];
        int maxSize = 0;

        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                if (a[i][j] == 1) {
                    if (i == 0 || j == 0)
                        s[i][j] = 1;
                    else
                        s[i][j] = Math.min(s[i - 1][j - 1], Math.min(s[i - 1][j], s[i][j - 1])) + 1;

                    maxSize = Math.max(maxSize, s[i][j]);
                }
        return maxSize;
    }

    public static void main(String[] args) {
        int n = StdIn.readInt();
        int[][] a = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                a[i][j] = StdIn.readInt();
        StdOut.println(size(a));
    }
}
