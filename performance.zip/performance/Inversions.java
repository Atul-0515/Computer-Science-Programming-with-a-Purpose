/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class Inversions {
    public static long count(int[] a) {
        long cnt = 0;
        for (int i = 0; i < a.length; i++)
            for (int j = i + 1; j < a.length; j++)
                if (a[i] > a[j]) cnt++;
        return cnt;
    }

    public static int[] generate(int n, long k) {
        int[] a = new int[n];
        int lo = 0, hi = n - 1;
        for (int i = 0; i < n; i++)
            if (k >= (n - i - 1)) {
                a[i] = hi;
                hi--;
                k -= (n - i - 1);
            }
            else {
                a[i] = lo;
                lo++;
            }
        return a;
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int k = Integer.parseInt(args[1]);
        int[] a = generate(n, k);
        for (int i = 0; i < a.length; i++)
            StdOut.print(a[i] + " ");
        StdOut.println();
    }
}
