/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class AudioCollage {
    public static double[] amplify(double[] a, double alpha) {
        double[] b = new double[a.length];
        for (int i = 0; i < a.length; i++) {
            b[i] = a[i] * alpha;
        }
        return b;
    }

    public static double[] reverse(double[] a) {
        double[] b = new double[a.length];
        for (int i = 0; i < a.length; i++)
            b[i] = a[a.length - i - 1];
        return b;
    }

    public static double[] merge(double[] a, double[] b) {
        double[] c = new double[a.length + b.length];
        int k = 0;
        for (int i = 0; i < a.length; i++)
            c[k++] = a[i];
        for (int i = 0; i < b.length; i++)
            c[k++] = b[i];
        return c;
    }

    public static double[] mix(double[] a, double[] b) {
        double[] c = new double[Math.max(a.length, b.length)];
        for (int i = 0; i < a.length; i++)
            c[i] += a[i];
        for (int i = 0; i < b.length; i++)
            c[i] += b[i];
        return c;
    }

    public static double[] changeSpeed(double[] a, double alpha) {
        double[] b = new double[(int) (a.length / alpha)];
        for (int i = 0; i < b.length; i++) {
            b[i] = a[(int) (i * alpha)];
        }
        return b;
    }

    private static double[] clipToRange(double[] audioSamples) {
        double[] a = new double[audioSamples.length];
        for (int i = 0; i < audioSamples.length; i++)
            a[i] = Math.max(-1.0, Math.min(1.0, audioSamples[i]));
        return a;
    }

    public static void main(String[] args) {
        double[] beatbox = StdAudio.read("beatbox.wav");
        double[] buzzer = StdAudio.read("buzzer.wav");
        double[] chimes = StdAudio.read("chimes.wav");
        double[] cow = StdAudio.read("cow.wav");
        double[] dialup = StdAudio.read("dialup.wav");

        StdAudio.play(clipToRange(amplify(beatbox, 2)));
        StdAudio.play(clipToRange(reverse(buzzer)));
        StdAudio.play(clipToRange(merge(chimes, cow)));
        StdAudio.play(clipToRange(mix(cow, dialup)));
        StdAudio.play(clipToRange(changeSpeed(beatbox, 2)));

    }
}
