/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class DiscreteDistribution {
    public static void main(String[] args) {
        int trials = Integer.parseInt(args[0]);
        int n = args.length;

        int[] arr = new int[n];

        for (int i = 1; i < n; i++) {
            arr[i] = Integer.parseInt(args[i]) + arr[i - 1];
        }

        for (int t = 0; t < trials; t++) {
            int r = (int) (Math.random() * arr[n - 1]);

            for (int i = 1; i < n; i++) {
                if (r < arr[i]) {
                    StdOut.print(i + " ");
                    break;
                }
            }

        }
        StdOut.println();
    }
}
