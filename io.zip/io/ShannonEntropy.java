/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class ShannonEntropy {
    public static void main(String[] args) {
        int m = Integer.parseInt(args[0]);

        int[] arr = new int[m + 1];
        int total = 0;

        while (!StdIn.isEmpty()) {
            int x = StdIn.readInt();
            arr[x]++;
            total++;
        }

        double shannonEntropy = 0.0;
        for (int i = 1; i <= m; i++) {
            if (arr[i] == 0) continue;
            double pi = (double) arr[i] / total;
            shannonEntropy += (pi * (Math.log(pi) / Math.log(2.0)));
        }
        shannonEntropy *= -1;
        StdOut.printf("%.4f%n", shannonEntropy);

    }
}
